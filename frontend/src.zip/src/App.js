import './App.css';
import { Mainroute } from './Routes/Mainroute';

function App() {
  return (
    <div className="App">
   <Mainroute/>
    </div>
  );
}

export default App;
